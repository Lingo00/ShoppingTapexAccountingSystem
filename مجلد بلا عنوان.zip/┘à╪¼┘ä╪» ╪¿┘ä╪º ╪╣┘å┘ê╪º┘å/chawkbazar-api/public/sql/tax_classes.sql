INSERT INTO `tax_classes` (`id`, `country`, `state`, `zip`, `city`, `rate`, `name`, `is_global`, `priority`, `on_shipping`, `created_at`, `updated_at`) VALUES
(1, 'United States', 'ny', '10001', 'ny', 2, 'Global', NULL, NULL, 1, '2021-10-25 05:05:58', '2021-11-28 07:25:09'),
(2, 'USA', 'NY', '1001', 'NY', 5, 'USA Tax', NULL, NULL, 1, '2021-11-28 07:38:04', '2021-11-28 07:38:04');