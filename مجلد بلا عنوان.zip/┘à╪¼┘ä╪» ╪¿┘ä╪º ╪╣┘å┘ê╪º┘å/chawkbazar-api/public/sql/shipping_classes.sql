INSERT INTO `shipping_classes` (`id`, `name`, `amount`, `is_global`, `type`, `created_at`, `updated_at`) VALUES
(1, 'Global', 50, '1', 'fixed', '2021-10-25 05:06:16', '2021-10-25 05:06:16'),
(2, 'Free Shippping To USA', 3, '1', 'free_shipping', '2021-11-28 07:36:37', '2021-11-28 07:37:22');