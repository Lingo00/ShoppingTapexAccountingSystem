INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`)
VALUES (2, 'Marvel\\Database\\Models\\User', 1),
    (4, 'Marvel\\Database\\Models\\User', 3),
    (4, 'Marvel\\Database\\Models\\User', 4),
    (4, 'Marvel\\Database\\Models\\User', 5);