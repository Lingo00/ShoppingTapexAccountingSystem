INSERT INTO `role_has_permissions` (`permission_id`, `role_id`)
VALUES (1, 1),
    (2, 1),
    (2, 2),
    (2, 3),
    (2, 4),
    (3, 1),
    (3, 2),
    (4, 3);