INSERT INTO `withdraws` (`id`, `shop_id`, `amount`, `payment_method`, `status`, `details`, `note`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 2, 500.00, 'cash', 'approved', 'need to with draw 500', NULL, NULL, '2021-11-28 06:39:42', '2021-11-28 07:24:08'),
(2, 2, 250.00, 'cash', 'on_hold', 'Need to withdraw 250', 'urgently required', NULL, '2021-11-28 07:15:08', '2021-11-28 07:20:31'),
(3, 2, 6500.00, 'cash', 'rejected', 'need to withdraw', NULL, NULL, '2021-11-28 07:17:48', '2021-11-28 07:20:51'),
(4, 2, 600.00, 'cash', 'on_hold', 'need urgently', 'need payment', NULL, '2021-11-28 07:21:20', '2021-11-28 17:13:39');