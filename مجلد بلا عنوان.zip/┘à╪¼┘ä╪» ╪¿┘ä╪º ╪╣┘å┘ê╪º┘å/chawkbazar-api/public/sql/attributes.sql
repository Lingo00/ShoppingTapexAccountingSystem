INSERT INTO `attributes` (`id`, `slug`, `name`, `shop_id`, `created_at`, `updated_at`) VALUES
(2, 'size', 'Size', 2, '2021-10-10 14:47:38', '2021-10-10 14:47:38'),
(3, 'color', 'Color', 2, '2021-10-10 14:48:43', '2021-10-10 14:48:43');