<?php
return [
    'view-order' => 'View order',
    'thanks'     => 'Thanks',
    'view-refund' => 'View refund',
];
