export const typeIconList = [
  {
    value: "FruitsVegetable",
    label: "Fruits and Vegetable",
  },
  {
    value: "FacialCare",
    label: "Facial Care",
  },
  {
    value: "Handbag",
    label: "Hand Bag",
  },
  {
    value: "DressIcon",
    label: "Dress Icon",
  },
  {
    value: "FurnitureIcon",
    label: "Furniture Icon",
  },
  {
    value: "BookIcon",
    label: "Book Icon",
  },
  {
    value: "MedicineIcon",
    label: "Medicine Icon",
  },
  {
    value: "Restaurant",
    label: "Restaurant",
  },
  {
    value: "Bakery",
    label: "Bakery",
  },
];
