import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'swiper/css/thumbs';
export { Navigation, Pagination, Scrollbar, A11y } from 'swiper/modules';
export { Swiper, SwiperSlide } from 'swiper/react';
